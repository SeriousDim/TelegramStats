# TelegramStats

Solution of the [Telegram Contest task](https://t.me/contest/6) (March 10-24 2019).
Android software for showing simple charts based on JSON input file (located in assets folder).

_No specialized charting libraries have not been used._
